"""
ia_mastering.py — Estrategia de mastering completa por IA.
La IA recibe el análisis completo del track y controla CADA plugin.
Si no hay IA disponible, usa el gap-based engine existente.
"""

from __future__ import annotations

import json
import pathlib
from typing import Any, Dict, Optional

from bandcamp_bok import call_ai_multi

from processes.catalog import function_registry
from processes.contracts import AudioFunctionAction, ContractError
from processes.audit import catalog_fingerprint, effective_execution_actions, fingerprint_audio_source


MASTERING_SYSTEM_PROMPT = """Sos un ingeniero de mastering senior.
Analizás cada track individualmente y solo podés decidir funciones presentes en el
catálogo recibido. Cada acción debe incluir function_id exacto, params, reason y
confidence. Para funciones multibanda o audio.tone_eq.band también debe incluir target
con uno de estos IDs: sub_bass, bass, low_mid, mid, high_mid, air.

Reglas de seguridad:
- No proceses una banda o problema que ya esté correcto.
- sub_bass nunca debe ensancharse por encima de 1.0.
- Evitá compresión, glue y saturación adicionales si LRA o crest ya son bajos.
- Conservá transientes y no uses parámetros fuera del catálogo.
- Incluí audio.loudness.normalize y audio.limiter.true_peak para la salida final.
- El orden de actions es el orden de procesamiento.
Respondé solo JSON válido, sin markdown."""

OUTPUT_SCHEMA = """{
  "audio_id": "ID recibido sin modificar",
  "diagnosis": "diagnóstico breve en español",
  "what_to_fix": ["problema concreto"],
  "what_to_keep": ["elemento que no debe alterarse"],
  "actions": [
    {
      "function_id": "audio.tone_eq.band",
      "enabled": true,
      "target": "low_mid",
      "params": {"frequency_hz": 350.0, "gain_db": -1.5, "q": 1.2, "filter_type": "peaking"},
      "reason": "Acumulación entre 250 y 500 Hz",
      "confidence": 0.85
    }
  ],
  "notes": ["decisión adicional"]
}"""


def _catalog_for_prompt() -> str:
    return json.dumps(function_registry.to_dict(), ensure_ascii=False, separators=(",", ":"))


def build_analysis_prompt(pre_stats: Dict[str, float], band_stats: Dict[str, float],
                          band_peaks: Dict[str, float], style: str,
                          target_lufs: float = -15.5, true_peak: float = -1.5,
                          voice_rms: Optional[float] = None,
                          stereo_width: float = 0.5, stereo_category: str = "Normal",
                          has_clipping: bool = False, noise_floor_db: float = -60,
                          audio_id: str = "unknown") -> str:
    """Construye el prompt completo con todas las métricas del track."""

    bands = ["Subbass (20-60 Hz)", "Bass (60-250 Hz)", "Low-Mid (250-500 Hz)",
             "Mid (500-2k Hz)", "High-Mid (2k-6k Hz)", "Air (6k-16k Hz)"]

    ideal_rms = {"Subbass (20-60 Hz)": -18, "Bass (60-250 Hz)": -14,
                 "Low-Mid (250-500 Hz)": -16, "Mid (500-2k Hz)": -15,
                 "High-Mid (2k-6k Hz)": -16, "Air (6k-16k Hz)": -18}
    ideal_peak = {"Subbass (20-60 Hz)": -3, "Bass (60-250 Hz)": -2,
                  "Low-Mid (250-500 Hz)": -2.5, "Mid (500-2k Hz)": -2.5,
                  "High-Mid (2k-6k Hz)": -3, "Air (6k-16k Hz)": -4}

    lines = [
        "=== ANÁLISIS COMPLETO DEL TRACK ===",
        f"Audio ID: {audio_id}",
        f"Estilo: {style}",
        f"LUFS integrado: {pre_stats.get('input_i', -35):.1f} LUFS",
        f"True Peak: {pre_stats.get('input_tp', -25):.1f} dBTP",
        f"LRA (rango dinámico): {pre_stats.get('input_lra', 7):.1f} LU",
        f"Crest factor: {pre_stats.get('crest_factor', 10):.1f} dB",
        f"Piso de ruido: {noise_floor_db:.1f} dB",
        f"Tiene clipping: {'sí' if has_clipping else 'no'}",
        f"Voz detectada: {'sí' if voice_rms and voice_rms > -30 else 'no'}",
        f"Ancho stereo: {stereo_width:.2f} ({stereo_category})",
        f"Target LUFS: {target_lufs}",
        f"Target True Peak: {true_peak} dBTP",
        "",
        "=== ANÁLISIS POR BANDA (RMS / Peak / Crest / Ideal RMS / Gap) ===",
    ]
    for band in bands:
        rms = band_stats.get(band, -70)
        peak = band_peaks.get(band, -70)
        crest = peak - rms if rms > -70 and peak > -70 else 0
        ideal = ideal_rms.get(band, -16)
        gap = rms - ideal
        lines.append(f"  {band}: RMS={rms:.1f}  Peak={peak:.1f}  Crest={crest:.1f}  Ideal={ideal}  Gap={gap:+.1f}")

    lines += [
        "",
        "=== PLUGINS DISPONIBLES Y SUS PARÁMETROS ===",
        _catalog_for_prompt(),
        "",
        "=== FORMato de RESPUESTA REQUERIDO ===",
        "Respondé EXACTAMENTE con este JSON, reemplazando los valores por tus decisiones:",
        OUTPUT_SCHEMA,
        "",
        "Solo el JSON, sin explicaciones ni markdown.",
    ]
    return "\n".join(lines)


def parse_mastering_response(response: str) -> Optional[Dict[str, Any]]:
    """Parsea la respuesta JSON de la IA."""
    try:
        text = response.strip()
        if text.startswith("```"):
            lines = text.split("\n")
            text = "\n".join(lines[1:-1])
        parsed = json.loads(text)
        return parsed if isinstance(parsed, dict) else None
    except (json.JSONDecodeError, Exception):
        return None


def validate_mastering_strategy(
    strategy: Dict[str, Any], *, audio_id: str, target_lufs: float,
    true_peak: float, pre_stats: Dict[str, float], source_fingerprint: str | None = None,
) -> Dict[str, Any]:
    """Valida acciones de IA, aplica guardrails y produce trazabilidad completa."""
    target_lufs = max(-70.0, min(-5.0, float(target_lufs)))
    true_peak = max(-9.0, min(0.0, float(true_peak)))
    allowed = {"audio_id", "diagnosis", "what_to_fix", "what_to_keep", "actions", "notes"}
    unknown = set(strategy) - allowed
    if unknown:
        raise ContractError(f"Campos desconocidos en estrategia IA: {sorted(unknown)}")
    if strategy.get("audio_id") != audio_id:
        raise ContractError("La IA devolvió un audio_id distinto al solicitado")
    raw_actions = strategy.get("actions")
    if not isinstance(raw_actions, list):
        raise ContractError("actions debe ser una lista")

    requested = []
    accepted: list[AudioFunctionAction] = []
    rejected = []
    lra = float(pre_stats.get("input_lra", 7.0))
    crest = float(pre_stats.get("crest_factor", 10.0))
    already_compressed = lra <= 4.5 or crest <= 8.5
    density_functions = {
        "audio.glue.bus_compressor", "audio.multiband.compressor",
        "audio.multiband.saturation", "audio.saturation.softclip",
    }

    for raw in raw_actions:
        requested.append(raw)
        try:
            if not isinstance(raw, dict):
                raise ContractError("Cada acción debe ser un objeto")
            if not str(raw.get("reason", "")).strip():
                raise ContractError("reason es obligatorio")
            if raw.get("confidence") is None:
                raise ContractError("confidence es obligatorio")
            action = function_registry.validate(AudioFunctionAction.from_dict(raw))
            if not action.enabled:
                raise ContractError("La IA no debe enviar acciones deshabilitadas; debe omitirlas")
            if already_compressed and action.function_id in density_functions:
                raise ContractError(
                    f"Guardrail: material ya comprimido (LRA={lra:.1f}, crest={crest:.1f})"
                )
            if (action.function_id == "audio.multiband.stereo_width"
                    and action.target == "sub_bass"
                    and float(action.params.get("width", 1.0)) > 1.0):
                raise ContractError("Guardrail: sub_bass no puede ensancharse por encima de 1.0")
            # Validar conflictos contra lo ya aceptado; la acción posterior se rechaza.
            function_registry.validate_plan([*accepted, action])
            accepted.append(action)
        except (ContractError, TypeError, ValueError) as exc:
            rejected.append({"action": raw, "error": str(exc)})

    injected: list[AudioFunctionAction] = []
    normalize = next((a for a in accepted if a.function_id == "audio.loudness.normalize"), None)
    if normalize is None:
        normalize = AudioFunctionAction(
            "audio.loudness.normalize",
            params={"target_lufs": target_lufs, "true_peak_db": true_peak, "lra": 11.0, "dual_mono": False},
            reason="Guardrail obligatorio de loudness", confidence=1.0,
        )
        accepted.append(normalize)
        injected.append(normalize)
    else:
        params = dict(normalize.params)
        params.update({"target_lufs": target_lufs, "true_peak_db": true_peak})
        replacement = AudioFunctionAction(
            normalize.function_id, normalize.enabled, params, normalize.target,
            normalize.reason, normalize.confidence,
        )
        accepted[accepted.index(normalize)] = function_registry.validate(replacement)
        normalize = replacement

    limiter = next((a for a in accepted if a.function_id == "audio.limiter.true_peak"), None)
    if limiter is None:
        limiter = AudioFunctionAction(
            "audio.limiter.true_peak",
            params={"ceiling_db": true_peak, "release_ms": 150.0, "lookahead_ms": 5.0,
                    "mode": "transparent", "oversampling": 4},
            reason="Guardrail obligatorio de True Peak", confidence=1.0,
        )
        accepted.append(limiter)
        injected.append(limiter)
    else:
        params = dict(limiter.params)
        params["ceiling_db"] = min(float(params.get("ceiling_db", true_peak)), true_peak)
        replacement = AudioFunctionAction(
            limiter.function_id, limiter.enabled, params, limiter.target,
            limiter.reason, limiter.confidence,
        )
        accepted[accepted.index(limiter)] = function_registry.validate(replacement)
        limiter = replacement

    # La salida siempre termina en normalización y limitador, aunque la IA los haya
    # colocado antes. Así el orden persistido coincide con el grafo realmente ejecutado.
    output_ids = {"audio.loudness.normalize", "audio.limiter.true_peak"}
    accepted = [action for action in accepted if action.function_id not in output_ids]
    accepted.extend([normalize, limiter])
    accepted = effective_execution_actions(accepted)

    normalized = dict(strategy)
    normalized["actions"] = [action.to_dict() for action in accepted]
    normalized["decision_trace"] = {
        "audio_id": audio_id,
        "catalog_fingerprint": catalog_fingerprint(),
        "source_fingerprint": source_fingerprint,
        "requested_actions": requested,
        "validated_actions": [action.to_dict() for action in accepted],
        "rejected_actions": rejected,
        "injected_guardrails": [action.to_dict() for action in injected],
        "effective_order": [action.function_id for action in accepted],
    }
    return normalized


def build_suno_classic_strategy(
    *, audio_id: str, target_lufs: float, true_peak: float,
    pre_stats: Dict[str, float], band_stats: Dict[str, float] | None = None,
    voice_rms: float | None = None, fallback_reason: str = "IA no disponible",
) -> Dict[str, Any]:
    """Fallback canónico: usa los mismos function_id, validación y traza que la IA."""
    bands = band_stats or {}
    actions: list[dict[str, Any]] = []

    def add(function_id: str, params: Dict[str, Any], reason: str, target: str | None = None) -> None:
        item: dict[str, Any] = {
            "function_id": function_id, "enabled": True, "params": params,
            "reason": reason, "confidence": 1.0,
        }
        if target:
            item["target"] = target
        actions.append(item)

    source_lufs = float(pre_stats.get("input_i", -24.0))
    add("audio.autogain.headroom", {"gain_db": -12.0 if source_lufs < -25.0 else -17.0},
        "SUNO Clásico: margen seguro antes del procesamiento")
    if voice_rms is not None and float(voice_rms) > -30.0:
        add("audio.deesser.sibilance_reduction", {"frequency_hz": 6000.0, "intensity": 0.4},
            "SUNO Clásico: control vocal conservador")
    if float(bands.get("High-Mid (2k-6k Hz)", -70.0)) > -22.0:
        add("audio.multiband.eq", {"gain_db": -0.8},
            "SUNO Clásico: suavizar dureza en presencia", "high_mid")
    if float(bands.get("Air (6k-16k Hz)", -70.0)) > -24.0:
        add("audio.multiband.eq", {"gain_db": -1.0},
            "SUNO Clásico: controlar aire metálico", "air")
    for target, width in (
        ("sub_bass", 0.0), ("bass", 0.4), ("low_mid", 0.7),
        ("high_mid", 1.15), ("air", 1.25),
    ):
        add("audio.multiband.stereo_width", {"width": width},
            "SUNO Clásico: imagen estéreo segura por banda", target)

    source_fingerprint = None
    try:
        source_path = pathlib.Path(audio_id)
        if source_path.is_file():
            source_fingerprint = fingerprint_audio_source(source_path)
    except (OSError, ValueError):
        pass
    strategy = validate_mastering_strategy(
        {
            "audio_id": audio_id,
            "diagnosis": "Fallback determinístico SUNO Clásico",
            "what_to_fix": [], "what_to_keep": ["dinámica y transientes"],
            "actions": actions,
            "notes": [fallback_reason],
        },
        audio_id=audio_id, target_lufs=target_lufs, true_peak=true_peak,
        pre_stats=pre_stats, source_fingerprint=source_fingerprint,
    )
    strategy["strategy_source"] = "fallback_suno_classic"
    strategy["fallback_preset"] = "SUNO Clásico"
    strategy["fallback_reason"] = fallback_reason
    return strategy


def get_mastering_strategy(
    band_stats: Dict[str, float],
    band_peaks: Dict[str, float],
    pre_stats: Dict[str, float],
    style: str = "SUNO",
    target_lufs: float = -15.5,
    true_peak: float = -1.5,
    providers: list | None = None,
    voice_rms: Optional[float] = None,
    stereo_width: float = 0.5,
    stereo_category: str = "Normal",
    has_clipping: bool = False,
    noise_floor_db: float = -60,
    past_examples: list | None = None,
    audio_id: str = "unknown",
) -> Optional[Dict[str, Any]]:
    """Intenta obtener estrategia de mastering completa por IA.
    Opcionalmente incluye ejemplos de estrategias pasadas exitosas para aprendizaje."""
    if not providers:
        return None

    source_fingerprint = None
    try:
        source_path = pathlib.Path(audio_id)
        if source_path.is_file():
            source_fingerprint = fingerprint_audio_source(source_path)
    except (OSError, ValueError):
        source_fingerprint = None

    prompt = build_analysis_prompt(
        pre_stats, band_stats, band_peaks, style, target_lufs, true_peak,
        voice_rms, stereo_width, stereo_category, has_clipping, noise_floor_db, audio_id
    )
    # Inyectar ejemplos pasados si existen
    if past_examples:
        prompt += "\n\n=== EJEMPLOS DE ESTRATEGIAS EXITOSAS ANTERIORES ===\n"
        prompt += "Usá estos como referencia de lo que funcionó bien en tracks similares:\n\n"
        for i, ex in enumerate(past_examples[:3], 1):
            diag = ex.get("diagnosis", "")
            fixes = ex.get("what_to_fix", [])
            keeps = ex.get("what_to_keep", [])
            prompt += f"Ejemplo {i}: {diag}\n"
            if fixes:
                prompt += f"  Se corrigió: {', '.join(fixes)}\n"
            if keeps:
                prompt += f"  Se mantuvo: {', '.join(keeps)}\n"
            actions = ex.get("actions", [])
            action_ids = [
                item.get("function_id") for item in actions
                if isinstance(item, dict) and item.get("function_id")
            ]
            if action_ids:
                prompt += f"  Funciones verificadas: {', '.join(action_ids)}\n"
            prompt += "\n"

    result = call_ai_multi(providers, MASTERING_SYSTEM_PROMPT, prompt,
                           max_tokens=2500, temperature=0.3)

    if not result:
        raise ContractError("El proveedor IA no devolvió respuesta (tokens, cuota o conexión)")
    parsed = parse_mastering_response(result)
    if not parsed:
        raise ContractError("La respuesta IA no contiene JSON válido")
    return validate_mastering_strategy(
        parsed, audio_id=audio_id, target_lufs=target_lufs,
        true_peak=true_peak, pre_stats=pre_stats,
        source_fingerprint=source_fingerprint,
    )


def load_past_strategies(log_dir: str = "", max_age_days: int = 30, max_count: int = 5) -> list:
    """Carga estrategias pasadas exitosas de archivos .ai_master.json en el directorio de logs.
    Solo incluye las que tienen rating 'Bueno' o fueron aplicadas por IA."""
    import json as _json
    import os as _os
    import time as _time
    from pathlib import Path as _Path

    examples = []
    now = _time.time()
    cutoff = now - max_age_days * 86400

    search_dirs = []
    if log_dir:
        search_dirs.append(_Path(log_dir))
    # También buscar en directorios de salida comunes
    for base in [_Path.home() / "Disco2" / "TeraBoxDownload",
                 _Path("/home/martin/Disco2/TeraBoxDownload")]:
        if base.exists():
            for d in base.iterdir():
                if d.is_dir() and (d / "log").exists():
                    search_dirs.append(d / "log")

    for log_path in search_dirs:
        if not log_path.exists():
            continue
        try:
            for f in sorted(log_path.glob("*.ai_master.json"), reverse=True):
                if len(examples) >= max_count:
                    break
                try:
                    if _os.path.getmtime(str(f)) < cutoff:
                        continue
                    data = _json.loads(f.read_text(encoding="utf-8"))
                    if data.get("used_ai_strategy") and data.get("status") == "applied":
                        audit = data.get("decision_trace", {}).get("execution_audit")
                        if isinstance(audit, dict) and audit.get("status") != "passed":
                            continue
                        adj = data.get("adjustments", {})
                        if isinstance(adj, dict):
                            examples.append({
                                "diagnosis": adj.get("diagnostics", ""),
                                "what_to_fix": adj.get("suggestions", []),
                                "what_to_keep": [],
                                "actions": data.get("executed_actions", []),
                                "file": str(f),
                            })
                except Exception:
                    continue
        except Exception:
            continue

    return examples[:max_count]
