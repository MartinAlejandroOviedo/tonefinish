# Contrato de funciones de audio

Este contrato es la fuente canónica de capacidades seleccionables por la IA.
Los nombres de clases, textos de UI y filtros FFmpeg pueden cambiar; los IDs no.

## Identidad

- Plugin: `audio.<plugin>`, por ejemplo `audio.multiband`.
- Función: `audio.<plugin>.<función>`, por ejemplo `audio.multiband.compressor`.
- Banda: `sub_bass`, `bass`, `low_mid`, `mid`, `high_mid` o `air`.

Nunca se deben persistir nombres traducidos de bandas como identidad. Un ID publicado
no se reutiliza para otra función. Los reemplazos se resuelven mediante alias.

## Acción decidida por IA

```json
{
  "function_id": "audio.multiband.compressor",
  "enabled": true,
  "target": "high_mid",
  "params": {
    "threshold_db": -20.0,
    "ratio": 1.5,
    "attack_ms": 3.0,
    "release_ms": 50.0
  },
  "reason": "Transientes agresivos entre 2 y 6 kHz",
  "confidence": 0.87
}
```

Antes de compilar un filtro se validan el ID, target, parámetros, rangos,
conflictos y métricas requeridas. Un campo o ID desconocido produce error explícito.

## Componentes

- `processes/contracts.py`: tipos, validación, contexto y fábrica de labels.
- `processes/catalog.py`: catálogo canónico y alias heredados.
- `BaseProcess.plugin_id`: identidad estable de cada plugin.
- `BaseProcess.function_specs()`: capacidades expuestas por el plugin.
- `BaseProcess.build_function()`: punto de compilación que implementará cada DSP.

La Fase 2 implementó `build_function()` en los nueve plugins registrados. Cada una
de las funciones se ejecuta en una prueba real de FFmpeg y debe conservar sample
rate y cantidad de canales. El método base mantiene `NotImplementedError` para que
un plugin futuro no pueda declarar funciones y omitir su implementación silenciosamente.

## Orquestación

Desde la Fase 3, `AudioProcessOrchestrator` es la única ruta que compila filtros DSP.
`audio_processing.py` conserva sus argumentos históricos, pero los convierte a
`AudioFunctionAction` con `migrate_legacy_preprocess_config()` y no contiene
implementaciones alternativas de EQ, dinámica, reparación, saturación o mastering.

El formato persistido por el antiguo `ProcessRegistry.to_dict()` se convierte con
`migrate_legacy_registry_state()`. Los valores traducidos de bandas se transforman
a IDs estables antes de compilar el grafo.

El catálogo actual contiene 27 funciones. Esto incluye ganancia de salida, recorte
de silencio y hard clipper, que anteriormente estaban implementados directamente
en `audio_processing.py`.

## Decisión IA y auditoría de salida

Desde la Fase 4, la IA recibe el catálogo vivo y responde acciones estructuradas con
`audio_id`, `function_id`, parámetros, motivo y confianza. Las acciones desconocidas,
conflictivas o inseguras se rechazan antes del render y quedan en `decision_trace`.

La Fase 5 cierra el circuito después del render. Cada `.ai_master.json` conserva la
huella SHA-256 del catálogo, el orden realmente ejecutado, métricas antes/después y
checks de cumplimiento de LUFS y True Peak. `status=warning` significa que el archivo
se produjo, pero una medición quedó fuera de tolerancia y requiere revisión; nunca se
presenta como éxito silencioso.

La Fase 6 endurece la correspondencia entre decisión y ejecución. Las acciones con
`enabled=false` se rechazan explícitamente, porque omitirlas en silencio falsearía la
traza. El plan efectivo se normaliza según las etapas físicas del pipeline: primero
preproceso, después loudness y por último el limitador True Peak. Tanto
`effective_order` como `executed_actions` reflejan ese orden real; los guardrails de
salida no pueden quedar anulados por el orden propuesto por un proveedor de IA.

La Fase 7 vincula la estrategia al contenido del audio mediante SHA-256. La huella se
calcula al pedir la decisión y se verifica otra vez justo antes de construir el grafo.
Si el archivo fue reemplazado o modificado —aunque conserve el mismo path— la ejecución
se detiene y exige un análisis nuevo. `source_fingerprint` queda guardado junto con
`audio_id`, la huella del catálogo y la auditoría final.

## Fallback sin IA

`SUNO Clásico` también se expresa como acciones canónicas. Si un proveedor agota
tokens, no responde o entrega JSON inválido, el sistema registra el motivo exacto y
genera un plan con los mismos `function_id`, guardrails, orden, huellas y auditoría que
una estrategia remota. No existe una ruta de procesamiento local opaca o manual.
