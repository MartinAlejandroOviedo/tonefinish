"""Contratos estables entre la IA, los plugins y el pipeline de audio."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, Mapping, Optional, Tuple
import re


ID_PATTERN = re.compile(r"^audio\.[a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*)+$")
PLUGIN_ID_PATTERN = re.compile(r"^audio\.[a-z][a-z0-9_]*$")
BAND_IDS = ("sub_bass", "bass", "low_mid", "mid", "high_mid", "air")


class ContractError(ValueError):
    """Error de definición o de validación del contrato de procesamiento."""


@dataclass(frozen=True)
class ParameterSpec:
    """Esquema compacto, serializable y apto para prompts de un parámetro."""

    value_type: str
    default: Any = None
    minimum: Optional[float] = None
    maximum: Optional[float] = None
    choices: Tuple[Any, ...] = ()
    required: bool = False
    description: str = ""

    def validate(self, name: str, value: Any) -> Any:
        expected = {
            "bool": bool,
            "int": int,
            "float": (int, float),
            "str": str,
        }.get(self.value_type)
        if expected is None:
            raise ContractError(f"Tipo de parámetro no soportado: {self.value_type}")
        if isinstance(value, bool) and self.value_type in ("int", "float"):
            raise ContractError(f"{name} debe ser {self.value_type}, no bool")
        if not isinstance(value, expected):
            raise ContractError(f"{name} debe ser {self.value_type}")
        if self.choices and value not in self.choices:
            raise ContractError(f"{name} debe ser uno de {self.choices}")
        if self.minimum is not None and value < self.minimum:
            raise ContractError(f"{name} debe ser >= {self.minimum}")
        if self.maximum is not None and value > self.maximum:
            raise ContractError(f"{name} debe ser <= {self.maximum}")
        return float(value) if self.value_type == "float" else value

    def to_dict(self) -> Dict[str, Any]:
        return {
            key: value for key, value in {
                "type": self.value_type, "default": self.default,
                "minimum": self.minimum, "maximum": self.maximum,
                "choices": list(self.choices), "required": self.required,
                "description": self.description,
            }.items() if value not in (None, (), [], "")
        }


@dataclass(frozen=True)
class AudioFunctionSpec:
    """Descripción estable de una capacidad que la IA puede seleccionar."""

    function_id: str
    plugin_id: str
    name: str
    description: str
    parameters: Mapping[str, ParameterSpec] = field(default_factory=dict)
    supported_targets: Tuple[str, ...] = ()
    conflicts_with: Tuple[str, ...] = ()
    requires_analysis: Tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not ID_PATTERN.fullmatch(self.function_id):
            raise ContractError(f"function_id inválido: {self.function_id}")
        if not PLUGIN_ID_PATTERN.fullmatch(self.plugin_id):
            raise ContractError(f"plugin_id inválido: {self.plugin_id}")

    def validate_action(self, action: "AudioFunctionAction") -> "AudioFunctionAction":
        if action.function_id != self.function_id:
            raise ContractError(f"La acción no corresponde a {self.function_id}")
        unknown = set(action.params) - set(self.parameters)
        if unknown:
            raise ContractError(f"Parámetros desconocidos para {self.function_id}: {sorted(unknown)}")
        missing = [k for k, spec in self.parameters.items() if spec.required and k not in action.params]
        if missing:
            raise ContractError(f"Parámetros requeridos ausentes: {missing}")
        if action.target is not None and action.target not in self.supported_targets:
            raise ContractError(f"Target inválido para {self.function_id}: {action.target}")
        if self.supported_targets and action.target is None:
            raise ContractError(f"{self.function_id} requiere target")
        validated = {k: self.parameters[k].validate(k, v) for k, v in action.params.items()}
        return AudioFunctionAction(
            function_id=action.function_id, enabled=action.enabled,
            params=validated, target=action.target, reason=action.reason,
            confidence=action.confidence,
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "function_id": self.function_id, "plugin_id": self.plugin_id,
            "name": self.name, "description": self.description,
            "parameters": {k: v.to_dict() for k, v in self.parameters.items()},
            "supported_targets": list(self.supported_targets),
            "conflicts_with": list(self.conflicts_with),
            "requires_analysis": list(self.requires_analysis),
        }


@dataclass(frozen=True)
class AudioFunctionAction:
    """Decisión de IA ya asociada a una función estable."""

    function_id: str
    enabled: bool = True
    params: Mapping[str, Any] = field(default_factory=dict)
    target: Optional[str] = None
    reason: str = ""
    confidence: Optional[float] = None

    def __post_init__(self) -> None:
        if self.confidence is not None and not 0.0 <= self.confidence <= 1.0:
            raise ContractError("confidence debe estar entre 0 y 1")

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "AudioFunctionAction":
        allowed = {"function_id", "enabled", "params", "target", "reason", "confidence"}
        unknown = set(data) - allowed
        if unknown:
            raise ContractError(f"Campos desconocidos en acción: {sorted(unknown)}")
        if "function_id" not in data:
            raise ContractError("function_id es obligatorio")
        return cls(
            function_id=data["function_id"], enabled=data.get("enabled", True),
            params=data.get("params", {}), target=data.get("target"),
            reason=data.get("reason", ""), confidence=data.get("confidence"),
        )

    def to_dict(self) -> Dict[str, Any]:
        result = {
            "function_id": self.function_id, "enabled": self.enabled,
            "params": dict(self.params),
        }
        if self.target is not None:
            result["target"] = self.target
        if self.reason:
            result["reason"] = self.reason
        if self.confidence is not None:
            result["confidence"] = self.confidence
        return result


@dataclass(frozen=True)
class AudioProcessContext:
    """Datos inmutables del audio disponibles para todos los plugins."""

    audio_id: str
    sample_rate: int
    channels: int
    duration: Optional[float] = None
    analysis: Mapping[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.audio_id:
            raise ContractError("audio_id es obligatorio")
        if self.sample_rate <= 0 or self.channels <= 0:
            raise ContractError("sample_rate y channels deben ser positivos")


class FilterLabelFactory:
    """Genera labels FFmpeg únicos y deterministas dentro de un grafo."""

    def __init__(self) -> None:
        self._counters: Dict[str, int] = {}

    def new(self, function_id: str, suffix: str = "out") -> str:
        stem = function_id.removeprefix("audio.").replace(".", "_")
        stem = re.sub(r"[^a-zA-Z0-9_]", "_", stem)
        key = f"{stem}_{suffix}"
        self._counters[key] = self._counters.get(key, 0) + 1
        return f"{key}_{self._counters[key]}"


class AudioFunctionRegistry:
    """Catálogo único de funciones, plugins y alias de compatibilidad."""

    def __init__(self, aliases: Optional[Mapping[str, str]] = None) -> None:
        self._specs: Dict[str, AudioFunctionSpec] = {}
        self._aliases = dict(aliases or {})

    def register(self, spec: AudioFunctionSpec) -> None:
        if spec.function_id in self._specs:
            raise ContractError(f"function_id duplicado: {spec.function_id}")
        self._specs[spec.function_id] = spec

    def register_many(self, specs: Iterable[AudioFunctionSpec]) -> None:
        for spec in specs:
            self.register(spec)

    def resolve_id(self, function_id: str) -> str:
        resolved = self._aliases.get(function_id, function_id)
        if resolved not in self._specs:
            raise ContractError(f"function_id desconocido: {function_id}")
        return resolved

    def get(self, function_id: str) -> AudioFunctionSpec:
        return self._specs[self.resolve_id(function_id)]

    def validate(self, action: AudioFunctionAction) -> AudioFunctionAction:
        resolved = self.resolve_id(action.function_id)
        normalized = AudioFunctionAction(
            function_id=resolved, enabled=action.enabled, params=action.params,
            target=action.target, reason=action.reason, confidence=action.confidence,
        )
        return self._specs[resolved].validate_action(normalized)

    def validate_plan(
        self,
        actions: Iterable[AudioFunctionAction],
        context: Optional[AudioProcessContext] = None,
    ) -> Tuple[AudioFunctionAction, ...]:
        """Valida una decisión completa, incluidos conflictos y análisis requerido."""
        validated = tuple(self.validate(action) for action in actions)
        enabled_ids = {action.function_id for action in validated if action.enabled}
        for action in validated:
            if not action.enabled:
                continue
            spec = self._specs[action.function_id]
            conflicts = enabled_ids.intersection(spec.conflicts_with)
            if conflicts:
                raise ContractError(
                    f"{action.function_id} entra en conflicto con {sorted(conflicts)}"
                )
            if context is not None:
                missing = [key for key in spec.requires_analysis if key not in context.analysis]
                if missing:
                    raise ContractError(
                        f"{action.function_id} requiere análisis ausente: {missing}"
                    )
        return validated

    def all(self) -> Tuple[AudioFunctionSpec, ...]:
        return tuple(self._specs.values())

    def for_plugin(self, plugin_id: str) -> Tuple[AudioFunctionSpec, ...]:
        return tuple(spec for spec in self._specs.values() if spec.plugin_id == plugin_id)

    def to_dict(self) -> Dict[str, Any]:
        return {"functions": [s.to_dict() for s in self.all()], "aliases": dict(self._aliases)}
