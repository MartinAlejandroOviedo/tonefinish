"""
Análisis de espectro de frecuencias para mejorar decisiones automáticas.

Este módulo genera visualizaciones del espectro y extrae características
detalladas para optimizar la configuración de presets.
"""

from __future__ import annotations

import subprocess
import json
import pathlib
import time
from typing import Dict, List, Tuple, Optional, Any

import numpy as np

try:
    import cupy as cp  # type: ignore
    CUPY_AVAILABLE = True
except Exception:
    cp = None  # type: ignore
    CUPY_AVAILABLE = False


def _normalize_backend(backend: str | None) -> str:
    normalized = (backend or "auto").strip().lower()
    if normalized in {"gpu", "cuda"}:
        return "gpu"
    if normalized in {"cpu", "numpy"}:
        return "cpu"
    return "auto"


def _gpu_backend_available() -> bool:
    return CUPY_AVAILABLE


def _hardware_gpu_available() -> bool:
    try:
        from resource_monitor import ResourceMonitor

        return ResourceMonitor().has_gpu()
    except Exception:
        return False


def _extract_segment(
    input_path: pathlib.Path,
    duration: float,
    verbose: bool,
) -> tuple[np.ndarray, int]:
    """Extrae un segmento mono a 44.1 kHz para análisis espectral."""
    probe_cmd = [
        "ffprobe",
        "-v",
        "quiet",
        "-print_format",
        "json",
        "-show_format",
        str(input_path),
    ]

    if verbose:
        print(f"$ {' '.join(probe_cmd)}")

    result = subprocess.run(probe_cmd, capture_output=True, text=True)
    probe_data = json.loads(result.stdout)
    total_duration = float(probe_data["format"]["duration"])

    start_time = max(0, (total_duration / 2.0) - (duration / 2.0))

    extract_cmd = [
        "ffmpeg",
        "-v",
        "quiet",
        "-ss",
        str(start_time),
        "-t",
        str(duration),
        "-i",
        str(input_path),
        "-ac",
        "1",
        "-ar",
        "44100",
        "-f",
        "f32le",
        "-",
    ]

    if verbose:
        print(f"$ {' '.join(extract_cmd)}")

    result = subprocess.run(extract_cmd, capture_output=True)
    audio_data = np.frombuffer(result.stdout, dtype=np.float32)
    if len(audio_data) == 0:
        raise ValueError("No se pudo extraer datos de audio")
    return audio_data, 44100


def _compute_spectrum_cpu(
    audio_data: np.ndarray,
    sample_rate: int,
) -> tuple[np.ndarray, np.ndarray, list[tuple[float, float]], float, float, float]:
    n = len(audio_data)
    fft = np.fft.rfft(audio_data)
    frequencies = np.fft.rfftfreq(n, 1 / sample_rate)
    magnitudes = 20 * np.log10(np.abs(fft) + 1e-10)
    magnitudes = magnitudes - np.max(magnitudes)
    peaks = _detect_peaks(frequencies, magnitudes)
    power = np.abs(fft) ** 2
    spectral_centroid = float(np.sum(frequencies * power) / np.sum(power))
    cumulative_power = np.cumsum(power)
    total_power = cumulative_power[-1]
    rolloff_idx = np.where(cumulative_power >= 0.85 * total_power)[0][0]
    spectral_rolloff = float(frequencies[rolloff_idx])
    geometric_mean = float(np.exp(np.mean(np.log(np.abs(fft) + 1e-10))))
    arithmetic_mean = float(np.mean(np.abs(fft)))
    spectral_flatness = float(geometric_mean / (arithmetic_mean + 1e-10))
    return frequencies, magnitudes, peaks, spectral_centroid, spectral_rolloff, spectral_flatness


def _compute_spectrum_gpu(
    audio_data: np.ndarray,
    sample_rate: int,
) -> tuple[np.ndarray, np.ndarray, list[tuple[float, float]], float, float, float]:
    if not CUPY_AVAILABLE or cp is None:
        return _compute_spectrum_cpu(audio_data, sample_rate)

    gpu_audio = cp.asarray(audio_data)
    n = int(gpu_audio.shape[0])
    fft = cp.fft.rfft(gpu_audio)
    frequencies = cp.fft.rfftfreq(n, 1 / sample_rate)
    magnitudes = 20 * cp.log10(cp.abs(fft) + 1e-10)
    magnitudes = magnitudes - cp.max(magnitudes)

    freq_np = cp.asnumpy(frequencies)
    mag_np = cp.asnumpy(magnitudes)
    peaks = _detect_peaks(freq_np, mag_np)

    power = cp.abs(fft) ** 2
    spectral_centroid = float(cp.sum(frequencies * power) / cp.sum(power))
    cumulative_power = cp.cumsum(power)
    total_power = cumulative_power[-1]
    rolloff_idx = int(cp.argmax(cumulative_power >= (0.85 * total_power)))
    spectral_rolloff = float(freq_np[rolloff_idx])
    geometric_mean = float(cp.exp(cp.mean(cp.log(cp.abs(fft) + 1e-10))))
    arithmetic_mean = float(cp.mean(cp.abs(fft)))
    spectral_flatness = float(geometric_mean / (arithmetic_mean + 1e-10))
    return freq_np, mag_np, peaks, spectral_centroid, spectral_rolloff, spectral_flatness


def _detect_peaks(frequencies: np.ndarray, magnitudes: np.ndarray) -> list[tuple[float, float]]:
    peaks = []
    threshold = -20.0
    min_separation = 100
    for i in range(1, len(magnitudes) - 1):
        if magnitudes[i] > threshold:
            if magnitudes[i] > magnitudes[i - 1] and magnitudes[i] > magnitudes[i + 1]:
                if not peaks or abs(frequencies[i] - peaks[-1][0]) > min_separation:
                    peaks.append((float(frequencies[i]), float(magnitudes[i])))
    peaks.sort(key=lambda x: x[1], reverse=True)
    return peaks[:10]


def analyze_spectrum_fft(
    input_path: pathlib.Path,
    duration: float = 10.0,
    verbose: bool = False,
    backend: str = "auto",
) -> Dict[str, Any]:
    """
    Analiza el espectro de frecuencias usando FFT.
    
    Args:
        input_path: Ruta al archivo de audio
        duration: Duración a analizar en segundos (desde el centro)
        verbose: Mostrar comandos
        backend: "auto", "cpu" o "gpu"
        
    Returns:
        Diccionario con datos del espectro:
        - frequencies: Array de frecuencias (Hz)
        - magnitudes: Array de magnitudes (dB)
        - peaks: Frecuencias con picos prominentes
        - spectral_centroid: Centro espectral en Hz
        - spectral_rolloff: Frecuencia de rolloff 85%
        - spectral_flatness: Planitud espectral (0-1)
    """
    backend = _normalize_backend(backend)
    audio_data, sample_rate = _extract_segment(input_path, duration, verbose)
    if backend == "gpu" and not _gpu_backend_available():
        backend = "cpu"

    if backend == "gpu":
        frequencies, magnitudes, peaks, spectral_centroid, spectral_rolloff, spectral_flatness = _compute_spectrum_gpu(
            audio_data, sample_rate
        )
    else:
        frequencies, magnitudes, peaks, spectral_centroid, spectral_rolloff, spectral_flatness = _compute_spectrum_cpu(
            audio_data, sample_rate
        )

    return {
        "frequencies": frequencies.tolist(),
        "magnitudes": magnitudes.tolist(),
        "peaks": peaks,
        "spectral_centroid": float(spectral_centroid),
        "spectral_rolloff": float(spectral_rolloff),
        "spectral_flatness": float(spectral_flatness),
        "sample_rate": sample_rate,
        "duration_analyzed": duration
    }


def benchmark_spectrum_fft(
    input_path: pathlib.Path,
    duration: float = 10.0,
    verbose: bool = False,
    runs: int = 3,
) -> Dict[str, Any]:
    """Compara CPU vs GPU para el análisis espectral si GPU está disponible."""
    hardware_available = _hardware_gpu_available()
    backend_available = _gpu_backend_available()
    results: Dict[str, Any] = {
        "cpu_seconds": [],
        "gpu_seconds": [],
        "gpu_hardware_available": hardware_available,
        "gpu_backend_available": backend_available,
        "gpu_available": hardware_available and backend_available,
    }

    for _ in range(max(1, runs)):
        start = time.perf_counter()
        analyze_spectrum_fft(input_path, duration=duration, verbose=verbose, backend="cpu")
        results["cpu_seconds"].append(time.perf_counter() - start)

    if results["gpu_available"]:
        for _ in range(max(1, runs)):
            start = time.perf_counter()
            analyze_spectrum_fft(input_path, duration=duration, verbose=verbose, backend="gpu")
            results["gpu_seconds"].append(time.perf_counter() - start)

    cpu_avg = sum(results["cpu_seconds"]) / len(results["cpu_seconds"])
    results["cpu_avg_seconds"] = cpu_avg
    if results["gpu_seconds"]:
        gpu_avg = sum(results["gpu_seconds"]) / len(results["gpu_seconds"])
        results["gpu_avg_seconds"] = gpu_avg
        results["speedup"] = cpu_avg / gpu_avg if gpu_avg > 0 else None
    else:
        results["gpu_avg_seconds"] = None
        results["speedup"] = None

    speedup = results.get("speedup")
    if not hardware_available:
        results["recommended_next_stage"] = "cpu_only"
    elif not backend_available:
        results["recommended_next_stage"] = "gpu_backend_missing"
    elif isinstance(speedup, (int, float)):
        if speedup >= 1.25:
            results["recommended_next_stage"] = "analysis.features"
        else:
            results["recommended_next_stage"] = "analysis.spectrum"
    else:
        results["recommended_next_stage"] = "cpu_only"
    return results


def get_spectrum_characteristics(spectrum_data: Dict) -> Dict[str, Any]:
    """
    Extrae características interpretables del espectro para Auto-Master.
    
    Args:
        spectrum_data: Datos del analyze_spectrum_fft
        
    Returns:
        Características del espectro:
        - has_sub_bass: Hay energía significativa < 60 Hz
        - has_bass_punch: Pico prominente en 60-250 Hz
        - has_muddy_mids: Exceso en 250-500 Hz
        - has_vocal_clarity: Energía balanceada en 1-4 kHz
        - has_air: Presencia en > 10 kHz
        - is_bright: Centro espectral > 2 kHz
        - is_warm: Centro espectral < 1 kHz
        - needs_deess: Picos excesivos en 5-8 kHz
    """
    peaks = spectrum_data["peaks"]
    centroid = spectrum_data["spectral_centroid"]
    rolloff = spectrum_data["spectral_rolloff"]
    flatness = spectrum_data["spectral_flatness"]
    
    # Analizar distribución de picos por bandas
    sub_bass_peaks = [p for p in peaks if 20 <= p[0] <= 60]
    bass_peaks = [p for p in peaks if 60 <= p[0] <= 250]
    low_mid_peaks = [p for p in peaks if 250 <= p[0] <= 500]
    mid_peaks = [p for p in peaks if 500 <= p[0] <= 2000]
    high_mid_peaks = [p for p in peaks if 2000 <= p[0] <= 6000]
    air_peaks = [p for p in peaks if 6000 <= p[0] <= 16000]
    ultra_high_peaks = [p for p in peaks if p[0] > 10000]
    
    # Detectar características
    has_sub_bass = len(sub_bass_peaks) > 0
    has_bass_punch = len(bass_peaks) > 0 and any(p[1] > -15 for p in bass_peaks)
    has_muddy_mids = len(low_mid_peaks) > 1  # Múltiples picos = muddy
    has_vocal_clarity = len(mid_peaks) > 0 and len(high_mid_peaks) > 0
    has_air = len(ultra_high_peaks) > 0
    is_bright = centroid > 2000
    is_warm = centroid < 1000
    needs_deess = any(5000 <= p[0] <= 8000 and p[1] > -10 for p in peaks)
    
    return {
        "has_sub_bass": has_sub_bass,
        "has_bass_punch": has_bass_punch,
        "has_muddy_mids": has_muddy_mids,
        "has_vocal_clarity": has_vocal_clarity,
        "has_air": has_air,
        "is_bright": is_bright,
        "is_warm": is_warm,
        "needs_deess": needs_deess,
        "spectral_centroid": centroid,
        "spectral_rolloff": rolloff,
        "spectral_flatness": flatness,
        "peak_count_by_band": {
            "Sub Bass (20-60 Hz)": len(sub_bass_peaks),
            "Bass (60-250 Hz)": len(bass_peaks),
            "Low-Mid (250-500 Hz)": len(low_mid_peaks),
            "Mid (500-2k Hz)": len(mid_peaks),
            "High-Mid (2-6k Hz)": len(high_mid_peaks),
            "Air (6-16k Hz)": len(air_peaks),
        }
    }


def generate_spectrum_plot_data(
    spectrum_data: Dict,
    freq_range: Tuple[float, float] = (20, 20000)
) -> Tuple[List[float], List[float]]:
    """
    Prepara datos para graficar el espectro.
    
    Args:
        spectrum_data: Datos del analyze_spectrum_fft
        freq_range: Rango de frecuencias a mostrar (Hz)
        
    Returns:
        (frequencies, magnitudes) filtradas por rango
    """
    frequencies = np.array(spectrum_data["frequencies"])
    magnitudes = np.array(spectrum_data["magnitudes"])
    
    # Filtrar por rango
    mask = (frequencies >= freq_range[0]) & (frequencies <= freq_range[1])
    filtered_freqs = frequencies[mask]
    filtered_mags = magnitudes[mask]
    
    return filtered_freqs.tolist(), filtered_mags.tolist()


def recommend_preset_from_spectrum(characteristics: Dict) -> str:
    """
    Recomienda un preset basado en características del espectro.
    
    Args:
        characteristics: Resultado de get_spectrum_characteristics
        
    Returns:
        Nombre del preset recomendado
    """
    # Lógica de recomendación basada en espectro
    if characteristics["has_bass_punch"] and characteristics["has_air"]:
        if characteristics["needs_deess"]:
            return "Fuego (Trap, Reguetón, Hip-Hop)"
        else:
            return "Empuje (EDM, Dubstep, Bass Music)"
    
    elif characteristics["has_vocal_clarity"]:
        if characteristics["is_bright"]:
            return "Claridad (Clásica, R&B, Cantautor)"
        elif characteristics["is_warm"]:
            return "Cinta (Jazz, Alternativa, Indie)"
        else:
            return "Universal (Rock, Pop, Electrónica)"
    
    elif characteristics["has_air"] and characteristics["spectral_flatness"] > 0.3:
        return "Espacial (Ambient, Experimental)"
    
    elif characteristics["is_warm"] and not characteristics["has_bass_punch"]:
        return "Natural (Acústico, Jazz, Folk)"
    
    elif characteristics["has_muddy_mids"]:
        return "Cinemático (Orquestal, Soundtrack)"
    
    else:
        return "Universal (Rock, Pop, Electrónica)"
